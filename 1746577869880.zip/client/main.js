fetch('http://localhost:3000/api/products')
  .then(res => res.json())
  .then(data => {
    const list = document.getElementById('product-list');
    data.forEach(product => {
      const div = document.createElement('div');
      div.innerHTML = `
        <h2>${product.name}</h2>
        <p>${product.description}</p>
        <p>${product.isPreorder ? 'Pre-order' : '$' + product.price}</p>
        <button>${product.isPreorder ? 'Pre-Order' : 'Buy Now'}</button>
      `;
      list.appendChild(div);
    });
  });
