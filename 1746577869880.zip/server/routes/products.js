const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// Sample data (you can connect this to a real DB)
router.get('/', async (req, res) => {
  const sampleProducts = [
    { name: 'Sneaker A', description: 'Hot new release', price: 200, isPreorder: true },
    { name: 'Sneaker B', description: 'In stock now', price: 150, isPreorder: false }
  ];
  res.json(sampleProducts);
});

module.exports = router;
